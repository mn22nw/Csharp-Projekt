﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1DV402.S3
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            { // RecipeRepository add = new RecipeRepository();
                // add.Load();

                RecipeRepository repository = new RecipeRepository();  //anropar 
                repository.Load();
                repository.Path = "recipes.txt";

            }

            catch (ArgumentException ex)
            {
                Console.BackgroundColor = ConsoleColor.Red;
                Console.ForegroundColor = ConsoleColor.White;
                ViewErrorMessage(ex.Message);
                Console.ResetColor();
            }




        }

        public static void ViewErrorMessage(string message)
        {
            Console.BackgroundColor = ConsoleColor.Red;
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine(message);
            Console.ResetColor();
        }
    }



}


